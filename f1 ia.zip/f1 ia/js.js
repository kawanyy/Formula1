const carro1 = document.getElementById("carro1");
const carro2 = document.getElementById("carro2");
const carro3 = document.getElementById("carro3");
const carro4 = document.getElementById("carro4");
const carro5 = document.getElementById("carro5");

// Define a posição X da pista de chegada
const posicaoPistaChegada = 560;

// Variável para controlar o estado do movimento
let estaMovendo = false;

// Variavel para armazenar o carro vencedor
let carroVencedor = null;


function moverCarro(carro) {
    let x = 10; // Posição horizontal inicial
    const tempoInicial = Date.now(); // Tempo inicial
  
    // Define a velocidade do carro
    const velocidade = Math.random() * 10 + 1; // Gera um valor aleatório entre 1 e 10
  
    // Move o carro
    const intervalo = setInterval(() => {
      if (x >= posicaoPistaChegada) {
        clearInterval(intervalo);
        const tempoFinal = Date.now(); // Tempo final
        const tempoDecorrido = tempoFinal - tempoInicial; // Tempo decorrido
  
        // Registrar o tempo do carro
        temposCarros[carro.id] = tempoDecorrido;
  
        // Verificar se o carro é o vencedor
        if (!carroVencedor || temposCarros[carro.id] < temposCarros[carroVencedor.id]) {
          carroVencedor = carro;
        }
        
        
        if (Object.keys(temposCarros).length === 5) {
          exibirMensagemVencedor(carroVencedor);
        }
  
        return;
      }
  
      if (estaMovendo) {
        x += velocidade;
      }
  
      carro.style.left = `${x}px`;       //se nao der certo esse codigo, tente esse  carro.style.left = x + 'px'; } ,20);

    }, 20);



    
  }
  
  
  // Função para exibir a mensagem de vencedor
  function exibirMensagemVencedor(carroVencedor) {
    const mensagem = `O carro ${carroVencedor.id} venceu a corrida em ${temposCarros[carroVencedor.id]}ms!`; // se nao der certo, tente esse  const mensagem ='O carro ' + carroVencedor.id + ' venceu a corrida em' + temposCarros[carroVencedor.id] + 'ms!';
    alert(mensagem);
  }


  
  // Armazena os tempos de cada carro
  const temposCarros = {};
  
  // Inicia a corrida
  function iniciarCorrida() {
    estaMovendo = true;
  
    // Inicia o movimento de cada carro
    for (const carro of [carro1, carro2, carro3, carro4, carro5]) {
      setTimeout(moverCarro, Math.random() * 1000, carro);
    }

    
  }
// Inicia o movimento dos carros quando o botão for clicado
document.querySelector("button").addEventListener("click", () => {
  estaMovendo = true;

  // Inicia o movimento de cada carro
  for (const carro of [carro1, carro2, carro3, carro4, carro5]) {
    setTimeout(moverCarro, Math.random() * 1000, carro);
  }
});

